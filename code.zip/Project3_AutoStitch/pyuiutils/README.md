# pyuiutils
A collection of custom Tkinter widgets and tools. Focuses on improving interoperability with OpenCV.
